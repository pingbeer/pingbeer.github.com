<template>
  <div>
    <div class="x-header">
      <x-header class="head_img" :left-options="{showBack: false}" v-cloak><img v-if="imgs ==''" class="herder_img" src="../../assets/font-awesome/image/login.jpeg" alt=""> <img v-if="imgs !==''" class="herder_img" :src="imgs | image" alt=""> {{datanum.comShortname}}
        <router-link @click.native="Enter" style="color:#fff" slot="right" to="/quit">切换</router-link>
      </x-header>
    </div>
    <div class="big_first">
      <div class="sell public">
        <div>
          <span><span style="display:inline-block;width:4px;height:16px;background:#4284d9;position:relative;top:3px;"></span> 销售</span>
        </div>
        <ul>
          <router-link tag="li" to="/adressbook">
            <i class="iconfont" style="color:#4FC3C3;font-size: 2.7rem;">&#xe712;</i>
            <p>客户</p>
            
          </router-link>
          <router-link  tag="li" to="/sareport">
            <i class="iconfont" style="color:#EB6877;">&#xe710;</i>
            <p>销售单</p>
            <div style="height:0.75rem" v-show="Sone !==0" class="daiduizhang" v-cloak>{{Sone}}</div>
          </router-link>
          <router-link tag="li" to="/sdaishoukuan">
            <i class="iconfont" style="color:#EB6877;">&#xe716;</i>
            <p>对账收款</p>
            <div style="height:0.75rem" v-show="Stwo !==0" class="daishoukuan" v-cloak>{{Stwo}}</div>
          </router-link>
           <router-link tag="li" to="">
          
          </router-link>
         
        </ul>
         <ul>
           <router-link tag="li" @click.native="developed" to="">
            <i class="iconfont" style="color:#FEA219;">&#xe6f9;</i>
            <p>设计</p>
            
          </router-link>
           <router-link tag="li" @click.native="developed" to="">
            <i class="iconfont" style="color:#FEA219;">&#xe715;</i>
            <p>制作</p>
            
          </router-link>
          <router-link tag="li" @click.native="developed" to="">
            <i class="iconfont" style="color:#FEA219;">&#xe711;</i>
            <p>配送</p>
            
          </router-link>
          <router-link  tag="li" @click.native="developed" to="">
            <i class="iconfont" style="color:#FEA219;">&#xe713;</i>
            <p>安装</p>
            
          </router-link>
        </ul>
      </div>
      <div style="border-top:1px solid #f0f0f0;"></div>
      <div class="sell public">
        <div>
          <span><span style="display:inline-block;width:4px;height:16px;background:#4284d9;position:relative;top:3px;"></span> 采购</span>
        </div>
        <ul>
           <router-link tag="li" to="/supplier">
            <i class="iconfont" style="color:#4FC3C3;">&#xe6c3;</i>
            <p>供应商</p>
            
          </router-link>
          <router-link tag="li" to="/syreport">
            <i class="iconfont" style="color:#4284D9;">&#xe698;</i>
            <p>采购单</p>
            <div v-show="Pone !==0" class="duizhang" v-cloak>{{Pone}}</div>
          </router-link>
           <router-link tag="li" to="/sydaifukuan">
            <i class="iconfont" style="color:#4284D9;">&#xe717;</i>
            <p>对账付款</p>
            <div v-show="Ptwo !==0" class="daifukuan" v-cloak>{{Ptwo}}</div>
          </router-link>
           <router-link tag="li" @click.native="developed" to="">
            <i class="iconfont" style="color:#FEA219;">&#xe70d;</i>
            <p>加工进度</p>
           
          </router-link>
        </ul>
      </div>
      <div style="border-top:1px solid #f0f0f0;"></div>
      <div class="sell public">
        <div>
          <span><span style="display:inline-block;width:4px;height:16px;background:#4284d9;position:relative;top:2px;"></span> 财务</span>
        </div>
        <ul>
          <router-link tag="li" to="/everydaycost">
            <i class="iconfont" style="color:#15bc83;font-size: 2.2rem;">&#xe702;</i>
            <p>工资费用</p>
          </router-link>
          <router-link tag="li" @click.native="developed" to="">
            <i class="iconfont" style="color:#15bc83;font-size: 2.2rem;">&#xe70f;</i>
            <p>绩效提成</p>
          </router-link>
          
           <router-link tag="li" @click.native="developed" to="">
            <i class="iconfont" style="color:#15bc83;">&#xe704;</i>
            <p>预存款</p>
          </router-link>
           <router-link tag="li"  to="">
           
          </router-link>
        </ul>
      </div>
    </div>
    <div class="error_tips">程序猿正在玩命开发中，敬请期待 !</div>
  </div>
</template>
<script>
import { XHeader, Actionsheet, TransferDom } from 'vux';
import address from '../../url.js';
import $ from 'jquery';
export default {
  directives: {
    TransferDom
  },
  components: {
    XHeader,
    Actionsheet
  },
  data() {
    return {
      datanum: "",
      Sone: 0,
      Stwo: 0,
      Sthree: 0,
      Pone: 0,
      Ptwo: 0,
      imgs:""
    }
  },
  created() {
    this.getInfo();
  },
  methods: {
    getInfo() {
      var _this = this
      this.axios.get(address.basic + localStorage.getItem('token'))
        .then(function (data) {
         _this.imgs =  data.data.data.comLogoPath;
        })
        .catch(err => {

        })
      this.axios.get(address.workbench + localStorage.getItem('token'))
        .then(function (data) {
          if(data.data.code==-1){
             _this.$router.push('/login');
          }else{
            _this.datanum = data.data
          $.each(data.data.todo, function (key, val) {
            if (val.orderType == 'S' && val.orderStatus == '04') {
              _this.Sone = val.orderCount;
            } else if (val.orderType == 'S' && val.orderStatus == '07') {
              _this.Stwo = val.orderCount;
            } else if (val.orderType == 'S' && val.orderStatus == '01') {
              _this.Sthree = val.orderCount;
            } else if (val.orderType == 'P' && val.orderStatus == '04') {
              _this.Pone = val.orderCount;
            } else if (val.orderType == 'P' && val.orderStatus == '09') {
              _this.Ptwo = val.orderCount;
            }
          });
          }
        })
        .catch(err => {

        })
    },
  developed(){
    $(".error_tips").fadeIn(250).delay(500).fadeOut(250);
  }
}
}
</script>
<style scoped>
html {
  font-family: "微软雅黑";
}

.public>div {
  padding: .4rem  1rem 0;
  color:#999;
}
.public ul {
  width: 95%;
  display: flex;
  justify-content: center;
  margin: 1rem auto;
  text-align: center;
}
/*#onlysell{
  margin: 0;
  width: 100%;
  border-bottom: 1px solid #f2f2f2;
}
#onlysell li{
  padding: .5rem 0;
  width: 25%;
  border-right: 1px solid #f2f2f2;
}
#onlysell>li>span{
  display: inline-block;
  height: 4rem;
  width: 4rem;
  line-height: 4rem;
  border-radius: 50%;
  color: #CCC;
  background: #f2f2f2;
  font-size: 0.9rem;
  margin-top:.2rem;
  shangjia bao jia bu yi yang 
}
#onlysell>li i{
   font-size: 2.5rem;
   height: 2.8rem;
   width: 2.8rem;
   line-height: 2.8rem;
}*/
.public li {
  position: relative;
  display: inline-block;
  width: 25%;
}

.public li div {
  font-size: 0.9rem;
  position: absolute;
  top: -.5rem;
  padding: .2rem;
  left: 65%;
  background: #ff5151;
  min-width: 0.8rem;
  height: .8rem;
  border-radius: 1rem;
  line-height: .9rem;
  color: #fff;
  text-align: center;
}

.public li p {
  font-size: 0.9rem;
  color: #333;
}

.public li i {
  display: inline-block;
  font-size: 2.4rem;
  color: #4FA8EA;
  border-radius: 50%;
  height: 2.7rem;
  width: 2.7rem;
  line-height: 2.7rem;
  text-align: center;
}
.empty {
  height: 4.6rem;
}
.herder_img{
  height: 26px;
  width: 26px;
  border-radius: 50%;
  margin-top:8px;
  margin-right:14px;
  float: left;
}
.error_tips {
  position: absolute;
  height: 4rem;
  line-height: 4rem;
  top: 40%;
  width: 70%;
  margin: 0 auto;
  left: 15%;
  right: 15%;
  background: #000;
  border-radius: 0.5rem;
  z-index: 1100;
  opacity: 0.7;
  display: none;
  color: #fff;
  text-align: center;
  font-size: 14px;
}
.vux-header {
  background: #4284d9;
}
</style>
