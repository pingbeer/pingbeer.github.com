##ydz-app
    易对账移动端项目，支持iOS，Android平台，HTML5。主要用于易对账客户查看数据处理业务。
    
    1. 采用vue开发
    2. 使用cordova进行打包封装

