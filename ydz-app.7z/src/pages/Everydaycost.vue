<template>
    <div>
        <div class="x-header">
            <back-header>
                <p class="title">费用</p>
            </back-header>
        </div>
        <div class="big_first">
            <router-link tag="div"  class="everyday" to="/dayaccount">
                <i class="iconfont">&#xe6be;</i>
                <p class="account" style="margin-top: 10px;font-size:16px;">&#X3000;日常账本</p>
                <p class="account">&#X3000;记报销、差旅、办公费</p>
            </router-link>
            <router-link tag="div" class="salary" to="/salaryaccount">
                <i class="iconfont">&#xe702;</i>
                <p class="account" style="margin-top: 10px;font-size:16px;">&#X3000;工资账本</p>
                <p class="account">&#X3000;记工资、社保、奖金费</p>
            </router-link>
        </div>
    </div>
</template>
<script>
import BackHeader from '../common/BackHeader'
import address from '../url.js';
export default {
    components: {
        BackHeader
    },
    data() {
        return {
            show: false,
            show1: true,
            picked:"two"
        }
    },
    created() {
        this.getInfo();
    },
    methods: {
        getInfo() {
            // 
        }
    }
}
</script>
<style scoped>
    .iconfont{
        float: left;
        font-size: 50px;
        color: #fff;
        margin-left: 12px;
    }
    .everyday{
        margin-top:47%!important;
        height: 82px;
        width: 87%;
        background: #7eb1e4;
        margin: 0 auto;
        border-radius: 6px;
        overflow: hidden;
    }
    .salary{
        margin-top:50px!important;
        height: 82px;
        width: 87%;
        background: #f3a97c;
        margin: 0 auto;
        border-radius: 6px;
        overflow: hidden;
    }
  .account{
        line-height: 31px;
        font-size: 14px;
        color: #fff;
    }
   
</style>
