jQuery.cookie = function (name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        var path = options.path ? '; path=' + options.path : '';
        var domain = options.domain ? '; domain=' + options.domain : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};

var MyGame = {};
MyGame.Boot = function (game) {};
MyGame.Boot.prototype = {
    preload: function () {
        this.load.image('loading-text', 'loading-text.png?v1');
        this.load.image('loading-bar1', 'loading-bar1.png?v1');
        this.load.image('loading-bar2', 'loading-bar2.png?v1');
    },
    create: function () {
        this.input.maxPointers = 2;
        this.scale.scaleMode = 2;
        this.scale.pageAlignHorizontally = true;
        this.scale.pageAlignVertically = true;
        this.stage.disableVisibilityChange = true;
        this.state.start('Preloader');
        setTimeout(function () {
            game.canvas.style.visibility = 'visible';
        }, 100)
    }
};

MyGame.Preloader = function (game) {};
MyGame.Preloader.prototype = {
    create: function () {
        setTimeout(function () {
            game.state.start('Game');
        }, 100);
    },
    preload: function () {
        this.add.graphics(0, 0).beginFill(0x01b5ff).drawRect(0, 0, this.world.width, this.world.height);
        this.add.image(190, 524, "loading-text");
        this.add.image(190, 586, "loading-bar2");
        var preloadSprite = this.add.image(194, 590, "loading-bar1");
        game.load.setPreloadSprite(preloadSprite);
        this.load.image('bg', 'bg.jpg?v1');
        this.load.image('btn_push', 'btn_push.png?v1');
        this.load.image('csd', 'csd.png?v1');
        this.load.image('go', 'go.png?v1');
        this.load.image('jiazi_top', 'jiazi_top.png?v1');
        this.load.image('jiazi_left', 'jiazi_left.png?v1');
        this.load.image('jiazi_right', 'jiazi_right.png?v1');
        this.load.image('shadow', 'shadow.png?v1');
        this.load.image('music1', 'music1.png?v1');
        this.load.image('music2', 'music2.png?v1');
        this.load.image('music3', 'music3.png?v1');
        this.load.image('lianbu', 'lianbu.png?v1', 181, 138);
        this.load.image('p1', 'p1.png?v1');
        this.load.image('p2', 'p2.png?v1');
        this.load.image('p3', 'p3.png?v1');
        this.load.image('p4', 'p4.png?v1');
        this.load.image('p5', 'p5.png?v1');
        this.load.image('p6', 'p6.png?v1');
        this.load.spritesheet('cheer_team', 'cheer_team.png?v1', 145, 145);
        this.load.spritesheet('cheer_team2', 'cheer_team2.png?v1', 181, 138);
        this.load.image('rule_bg', 'rule_bg.png?v1');
        this.load.image('btn_know', 'btn_know.png?v1');
        this.load.image('share_pic1', 'share_pic1.png?v1');
        this.load.image('share_pic2', 'share_pic2.png?v1');
        this.load.image('btn_tryagain', 'btn_tryagain.png?v1');
        this.load.image('dialog_bg', 'dialog_bg.png?v1');
        this.load.image('title_losing1', 'title_losing1.png?v1');
        this.load.image('title_losing2', 'title_losing2.png?v1');
        this.load.image('bq1', 'bq1.png?v1');
        this.load.image('bq2', 'bq2.png?v1');
        this.load.image('btn_fuli', 'btn_fuli.png?v1');
        this.load.image('btn_share', 'btn_share.png?v1');
        this.load.image('text1', 'text1.png?v1');
        this.load.image('text2', 'text2.png?v1');
        this.load.image('text3', 'text3.png?v1');
        this.load.image('text4', 'text4.png?v1');
        this.load.image('dialog_bg2', 'dialog_bg2.png?v1');
        this.load.image('title_lottery', 'title_lottery.png?v1');
        this.load.image('p1_b', 'p1_b.png?v1');
        this.load.image('p2_b', 'p2_b.png?v1');
        this.load.image('p3_b', 'p3_b.png?v1');
        this.load.image('p4_b', 'p4_b.png?v1');
        this.load.image('p5_b', 'p5_b.png?v1');
        this.load.image('p6_b', 'p6_b.png?v1');
        this.load.image('text5', 'text5.png?v1');
        this.load.image('text5_2', 'text5_2.png?v1');
        this.load.image('text5_3', 'text5_3.png?v1');
        this.load.image('shape', 'shape.png?v1');
        this.load.image('btn_apply', 'btn_apply.png?v1');
        this.load.image('light', 'light.png?v1');
        this.load.image('close', 'close.png?v1');
        this.load.image('choujiang-bg', 'choujiang-bg.png?v1');
        this.load.image('text6', 'text6.png?v1');
        this.load.image('gl', 'gl.png?v1');
        this.load.image('title_nostart', 'title_nostart.png?v1');
        this.load.image('gift', 'gift.png?v1');
        this.load.image('text7', 'text7.png?v1');
        this.load.image('btn_come', 'btn_come.png?v1');
        this.load.audio('bg', 'sound/bg.mp3');
        this.load.audio('zhuaqu', 'sound/zhuaqu.mp3');
        this.load.audio('diaoluo', 'sound/diaoluo.mp3');
        this.load.audio('jiazhong', 'sound/jiazhong.mp3');
        this.load.audio('weizhongjiang', 'sound/weizhongjiang.mp3');
        this.load.audio('zhongjiang', 'sound/zhongjiang.mp3');
        this.load.image('shape1', 'shape1.png?v1');
        this.load.image('shape2', 'shape2.png?v1');
        this.load.image('shape3', 'shape3.png?v1');
        this.load.image('shape4', 'shape4.png?v1');
        this.load.image('shape5', 'shape5.png?v1');
        this.load.image('shape6', 'shape6.png?v1');
        this.load.image('music-switch', 'music-switch.png?v1');
        this.load.start();
    }
};

MyGame.Game = function (game) {
    this.speed = 200;
    this.gameRun = false;
    this.playGravity = 2000;
    this.score = 0;
    this.rnd = 0;
    this.createTime = 0;
    this.doubleJump = 0;
    this.dely = 0;
    this.timestamp = 0;
    this.direction = 1;
    this.isUp = false;
    this.isCatch = false;
    this.isDown = false;
    this.href = 'http://dongkaapp.allyes.com/view/2017819/app19go.html';
    this.href2 = 'http://creditcard.ecitic.com/h5/youhui/170113/index.html?sid=SJWZHD4';
    this.isSend = false;
    this.musicPause = false;

};
MyGame.Game.prototype = {
    create: function () {
        var _this = this;
        game.physics.startSystem(Phaser.Physics.ARCADE);
        this.soundBg = game.add.sound('bg');
        this.soundDiaoLuo = game.add.sound('diaoluo');
        this.soundJiaZhong = game.add.sound('jiazhong');
        this.soundWeiZhongJiang = game.add.sound('weizhongjiang');
        this.soundZhongJiang = game.add.sound('zhongjiang');
        this.soundZhuaQu = game.add.sound('zhuaqu');
        this.isgrabing = false;
        this.productsArray = [];
        this.add.image(0, 0, 'bg');
        this.liHua = game.add.group();
        this.liHua.enableBody = true;
        this.btnPush = this.add.button(271, 1007, 'btn_push', function () {
            this.scale.y = 0.5;
            setTimeout(function () {
                _this.btnPush.scale.y = 1;
            }, 100);
            if (_this.isCatch) {
                return
            }
            if (_this.isgrabing) {
                return
            }
            _this.isgrabing = true;
            _this.startGrab()

        }, 0);

        $.ajax({
            type: "post",
            url: "frmDL2017819CheckCj.aspx?rd=" + Math.random(),
            data: {
                openid: openid
            },
            dataType: "json",
            error: function (error) {
                console.log("%c请求异常", "color:#f44373");

            },
            success: function (data) {
                var Code = parseInt(data.Code),
                    Message = data.Message;
                if (Code == -3) {
                    //未到开始时间
                    _this.showNoBegin();
                } else if (Code == -4) {
                    //活动已结束
                    alert('活动已结束')
                } else if (Code == -5) {
                    //未登录
                    needLogin();
                } else if (Code == -8) {
                    _this.showNoChance()
                } else if (Code == -1) {
                    if (parseInt(data.lave) <= 0) {
                        _this.showNoChance()
                    } else {
                        _this.showNotWinning();
                    }
                } else if (Code == -55) {

                    _this.lottery2('p' + data.pid + '_b');
                } else {
                    _this.canPlay = true;
                    _this.showRule();
                }

            }
        });

        this.btnPush.anchor.setTo(0, 1);
        this.btnPush.x = 271;
        this.btnPush.y = 1095;
        this.csd = this.add.tileSprite(65, 764, 624, 140, 'csd');
        this.jiaziGroup = game.add.group();
        this.jiaziGroup.create(331, 379, 'shadow', 0);
        this.jiaziLeft = this.jiaziGroup.create(375, 382, 'jiazi_left', 0);
        this.jiaziRight = this.jiaziGroup.create(375, 382, 'jiazi_right', 0);
        this.jiaziLeft.anchor.setTo(0.896, 0.088);
        this.jiaziRight.anchor.setTo(0.104, 0.088);
        this.jiaziGroup.create(327, -390, 'jiazi_top', 0);
        this.add.image(0, 0, 'lianbu');
        this.add.image(356, 4, 'go');
        this.cheerTeam1 = game.add.sprite(26, 1035, 'cheer_team');
        this.cheerTeam2 = game.add.sprite(game.world.width - 174, 1035, 'cheer_team');
        this.cheerTeam3 = game.add.sprite(36, 7, 'cheer_team2');
        this.cheerTeam1.animations.add('cheer');
        this.cheerTeam1.animations.play('cheer', 2, true);
        setTimeout(function () {
            _this.cheerTeam2.animations.add('cheer');
            _this.cheerTeam2.animations.play('cheer', 2, true);
        }, 100);
        this.cheerTeam3.animations.add('cheer');
        this.cheerTeam3.animations.play('cheer', 2, true);
        this.music1 = game.add.image(this.cheerTeam3.x + 160, this.cheerTeam3.y + 35, 'music1');
        this.music2 = game.add.image(this.cheerTeam3.x + 160, this.cheerTeam3.y + 35, 'music2');
        this.music3 = game.add.image(this.cheerTeam3.x + 165, this.cheerTeam3.y + 35, 'music3');
        this.music1.x1 = this.music1.x;
        this.music1.y1 = this.music1.y;
        this.music2.x1 = this.music2.x;
        this.music2.y1 = this.music2.y;
        this.music3.x1 = this.music3.x;
        this.music3.y1 = this.music3.y;
        this.music1.alpha = 0;
        this.music2.alpha = 0;
        this.music3.alpha = 0;
        this.csd.autoScroll(-this.speed, 0);
        this.productsMask = game.add.graphics(0, 0);
        this.productsMask.beginFill(0xffffff);
        this.productsMask.drawRect(65, 227, 624, 680)
        this.productsGroup = this.add.group();
        this.productsGroup.mask = this.productsMask;

        this.musicSwitch = this.add.button(65, 95, 'music-switch', function () {
            if (_this.musicPause) {
                _this.musicPause = false;
                _this.soundBg.play();
            } else {
                _this.musicPause = true;
                _this.soundBg.stop();
            }
        }, 0);
        this.musicSwitch.anchor.setTo(0.5, 0.5);

        this.dialog = this.add.group();
        this.dialog.visible = false;
        this.dialogBg = this.add.graphics(0, 0).beginFill(0x000000, 0.7).drawRect(0, 0, this.world.width, this.world.height);
        this.dialogBg.inputEnabled = true;
        this.dialog.add(this.dialogBg);


        // 活动规则
        this.rule = this.add.group();
        var btnKnow = this.add.button(375, 766, 'btn_know', function () {
            if (this.disable) {
                return
            }
            this.disable = true;
            game.add.tween(_this.dialogBg).to({
                alpha: 0
            }, 800, Phaser.Easing.Back.In, true, 0);
            game.add.tween(_this.rule).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialog.visible = false;
                btnKnow.disable = false;
            })
        }, 0);
        btnKnow.anchor.setTo(0.5, 0.5);
        this.rule.create(0, 177, 'rule_bg', 0);
        this.rule.add(btnKnow);
        this.dialog.add(this.rule);




        //机会已用完
        this.noChance = this.add.group();
        this.noChance.create(0, 278, 'dialog_bg', 0);
        this.noChance.create(166, 248, 'title_losing2', 0);
        this.noChance.create(298, 352, 'bq1', 0);
        this.noChance.create(234, 578, 'text1', 0);
        var btnNochance = this.add.button(280, 730, 'btn_fuli', function () {
            if (this.disable) {
                return
            }
            this.disable = true;
            game.add.tween(_this.dialogBg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.noChance).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialog.visible = false;
                btnNochance.disable = false;
                window.location.href = _this.href;
            })
        }, 0);
        this.noChance.add(btnNochance);
        this.dialog.add(this.noChance);
        //机会已用完分享的一次机会
        this.noChance2 = this.add.group();
        this.noChance2.create(0, 278, 'dialog_bg', 0);
        this.noChance2.create(166, 248, 'title_losing2', 0);
        this.noChance2.create(298, 352, 'bq1', 0);
        this.noChance2.create(285, 594, 'text2', 0);
        this.noChance2.create(162, 670, 'text3', 0);
        var btnNoChance2 = this.add.button(165, 730, 'btn_fuli', function () {
            if (this.disable) {
                return
            }
            this.disable = true;
            game.add.tween(_this.dialogBg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.noChance2).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialog.visible = false
                btnNoChance2.disable = false;
                window.location.href = _this.href;
            })
        }, 0);
        var btnShare = this.add.button(384, 730, 'btn_share', function () {
            if (this.disable) {
                return
            }
            this.disable = true;
            sharepage();
            _this.playAgain();
            game.add.tween(_this.dialogBg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.noChance2).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialog.visible = false
                btnShare.disable = false;

            });
        }, 0);
        this.noChance2.add(btnNoChance2);
        this.noChance2.add(btnShare);
        this.dialog.add(this.noChance2);
        //未中奖
        this.notWinning = this.add.group();
        this.notWinning.create(0, 278, 'dialog_bg', 0);
        this.notWinning.create(117, 248, 'title_losing1', 0);
        this.notWinning.create(298, 352, 'bq1', 0);
        this.notWinning.create(212, 600, 'text4', 0);

        var bntNoWinning = this.add.button(263, 730, 'btn_tryagain', function () {
            if (this.disable) {
                return
            }
            this.disable = true;
            game.add.tween(_this.dialogBg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.notWinning).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialog.visible = false;
                bntNoWinning.disable = false;
                _this.playAgain();
            })
        }, 0);
        this.notWinning.add(bntNoWinning);
        this.dialog.add(this.notWinning);
        //中奖
        this.dialogLottery = this.add.group();
        this.dialogLottery.visible = false;
        this.dialogLotteryBg = this.add.graphics(0, 0).beginFill(0x000000, 0.7).drawRect(0, 0, this.world.width, this.world.height);
        this.dialogLotteryBg.inputEnabled = true;
        this.dialogLotteryBg.alpha = 0;
        this.dialogLottery.add(this.dialogLotteryBg);
        this.dialogLotteryC1 = this.add.group();
        this.dialogLotteryC1.y = -game.world.height
        this.light = this.add.sprite(375, 240, 'light');
        this.light.anchor.setTo(0.5, 0.47);
        this.dialogLotteryC1.add(this.light);
        this.dialogLotteryC1.create(122, 260, 'dialog_bg2', 0);
        this.dialogLotteryC1.create(82, 222, 'title_lottery', 0);
        this.dialogLotteryC1.create(188, 308, 'p1_b', 0);
        this.dialogLotteryC1.create(153, 591, 'text5', 0);
        var dialogLotteryC1Btn = this.add.button(348, 903, 'btn_apply', function () {
            if (this.disable) {
                return
            }
            this.disable = true;
            game.add.tween(_this.dialogLotteryBg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.dialogLotteryC1).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialogLottery.visible = false;
                window.location.href = _this.href2;
            })
        }, 0);
        var dialogLotteryC1Btn2 = this.add.button(142, 903, 'btn_fuli', function () {
            game.add.tween(_this.dialogLotteryBg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.dialogLotteryC1).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialogLottery.visible = false;
                window.location.href = _this.href;
            })
        }, 0);
        var dialogLotteryC1Btn3 = this.add.button(375, 1050, 'close', function () {
            game.add.tween(_this.dialogLotteryBg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.dialogLotteryC1).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialogLottery.visible = false;
                _this.playAgain();
            })
        }, 0)
        dialogLotteryC1Btn3.anchor.setTo(0.5, 0.5);
        this.dialogLotteryC1.add(dialogLotteryC1Btn);
        this.dialogLotteryC1.add(dialogLotteryC1Btn2);
        this.dialogLotteryC1.add(dialogLotteryC1Btn3);
        this.dialogLottery.add(this.dialogLotteryC1);


        //已中奖
        this.dialogLottery2 = this.add.group();
        this.dialogLottery2.visible = false;
        this.dialogLottery2Bg = this.add.graphics(0, 0).beginFill(0x000000, 0.7).drawRect(0, 0, this.world.width, this.world.height);
        this.dialogLottery2Bg.inputEnabled = true;
        this.dialogLottery2Bg.alpha = 0;
        this.dialogLottery2.add(this.dialogLottery2Bg);
        this.dialogLottery2C1 = this.add.group();
        this.dialogLottery2C1.y = -game.world.height
        this.light = this.add.sprite(375, 240, 'light');
        this.light.anchor.setTo(0.5, 0.47);
        this.dialogLottery2C1.add(this.light);
        this.dialogLottery2C1.create(122, 260, 'dialog_bg2', 0);
        this.dialogLottery2C1.create(111, 216, 'text5_3', 0);
        this.dialogLottery2C1.create(188, 308, 'p1_b', 0);
        this.dialogLottery2C1.create(153, 591, 'text5_2', 0);
        var dialogLottery2C1Btn = this.add.button(348, 903, 'btn_apply', function () {
            if (this.disable) {
                return
            }
            this.disable = true;
            game.add.tween(_this.dialogLottery2Bg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.dialogLottery2C1).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialogLottery2.visible = false;
                window.location.href = _this.href2;
            })
        }, 0);
        var dialogLottery2C1Btn2 = this.add.button(142, 903, 'btn_fuli', function () {
            game.add.tween(_this.dialogLottery2Bg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.dialogLottery2C1).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialogLottery2.visible = false;
                window.location.href = _this.href;
            })
        }, 0);
        var dialogLottery2C1Btn3 = this.add.button(375, 1050, 'close', function () {
            game.add.tween(_this.dialogLottery2Bg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.dialogLottery2C1).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                _this.dialogLottery2.visible = false;
                _this.playAgain();
            })
        }, 0)
        dialogLottery2C1Btn3.anchor.setTo(0.5, 0.5);
        this.dialogLottery2C1.add(dialogLottery2C1Btn);
        this.dialogLottery2C1.add(dialogLottery2C1Btn2);
        this.dialogLottery2C1.add(dialogLottery2C1Btn3);
        this.dialogLottery2.add(this.dialogLottery2C1);

        // 活动未开始弹窗
        this.notStart = this.add.group();
        this.notStart.create(0, 278, 'dialog_bg', 0);
        this.notStart.create(105, 246, 'title_nostart', 0);
        this.notStart.create(266, 382, 'gift', 0);
        this.notStart.create(235, 591, 'text7', 0);
        var notStartBtn = this.add.button(200, 730, 'btn_come', function () {
            if (this.disable) {
                return
            }
            this.disable = true
            game.add.tween(_this.dialogBg).to({
                alpha: 0
            }, 800, Phaser.Easing.Linear.none, true, 0);
            game.add.tween(_this.notStart).to({
                y: -game.world.height
            }, 800, Phaser.Easing.Back.In, true, 0).onComplete.add(function () {
                notStartBtn.disable = false;
                _this.dialog.visible = false;
            })
        }, 0);
        this.notStart.add(notStartBtn);
        this.dialog.add(this.notStart);
        this.soundBg.play('', 0, 1, true)
        game.time.events.loop(1500, this.createProducts, this);
        game.time.events.stop(false);
        game.time.events.start();
    },
    resetDialog: function () {
        this.dialog.visible = true;
        this.dialog.forEach(function (children) {
            if (children.z !== 0) {
                children.y = -game.world.height;
            } else {
                children.alpha = 0;
            }

        })
    },
    fadeInDialogBg: function () {
        game.add.tween(this.dialogBg).to({
            alpha: 1
        }, 800, Phaser.Easing.Linear.none, true, 0);
    },
    showNoBegin: function () {
        var _this = this;
        var p;
        setTimeout(function () {
            _this.productsGroup.forEach(function (i) {
                if (!i.moving) {
                    i.diaoluo = true;
                    p = i.getChildAt(1);
                }
            });
            setTimeout(function () {
                _this.resetDialog();
                _this.fadeInDialogBg();
                game.add.tween(_this.dialogBg).to({
                    alpha: 1
                }, 800, Phaser.Easing.Linear.none, true, 0);
                game.add.tween(_this.notStart).to({
                    y: 0
                }, 800, Phaser.Easing.Back.Out, true, 0);

            }, 1000)
        }, 1000)
    },
    showNotWinning: function () {
        var _this = this;
        var p;
        setTimeout(function () {
            _this.soundWeiZhongJiang.play();
            _this.productsGroup.forEach(function (i) {
                if (!i.moving) {
                    i.diaoluo = true;
                    p = i.getChildAt(1);
                }
            });
            setTimeout(function () {
                _this.resetDialog();
                _this.fadeInDialogBg();
                game.add.tween(_this.notWinning).to({
                    y: 0
                }, 800, Phaser.Easing.Back.Out, true, 0).onComplete.add(function () {
                    _this.isCatch = false;
                });

            }, 1000)

        }, 1000)
    },
    showNoChance: function () {
        var _this = this;
        var p;
        setTimeout(function () {
            _this.soundWeiZhongJiang.play();
            _this.productsGroup.forEach(function (i) {
                if (!i.moving) {
                    i.diaoluo = true;
                    p = i.getChildAt(1);
                }
            });
            setTimeout(function () {
                _this.resetDialog();
                _this.fadeInDialogBg();
                game.add.tween(_this.noChance).to({
                    y: 0
                }, 800, Phaser.Easing.Back.Out, true, 0);

            }, 1000)

        }, 1000)
    },
    showNoChance2: function () {
        var _this = this;
        var p;
        setTimeout(function () {
            _this.soundWeiZhongJiang.play();
            _this.productsGroup.forEach(function (i) {
                if (!i.moving) {
                    i.diaoluo = true;
                    p = i.getChildAt(1);
                }
            });
            setTimeout(function () {
                _this.resetDialog();
                _this.fadeInDialogBg();
                game.add.tween(_this.noChance2).to({
                    y: 0
                }, 800, Phaser.Easing.Back.Out, true, 0);
            }, 1000)
        }, 1000)
    },
    showRule: function () {
        var _this = this;
        this.resetDialog();
        this.fadeInDialogBg();
        game.add.tween(_this.rule).to({
            y: 0
        }, 800, Phaser.Easing.Back.Out, true, 0);
        return;
    },

    lotteryAni: function () {
        this.light.angle += 0.2;
    },
    lottery: function (pn) {
        if (!pn) {
            return
        }
        this.dialogLottery.visible = true;
        this.dialogLotteryC1.getChildAt(3).loadTexture(pn, 0)
        game.add.tween(this.dialogLotteryBg).to({
            alpha: 1
        }, 800, Phaser.Easing.Linear.none, true, 0);
        game.add.tween(this.dialogLotteryC1).to({
            y: 0
        }, 800, Phaser.Easing.Back.Out, true, 0)
    },
    lottery2: function (pn) {
        if (!pn) {
            return
        }
        this.dialogLottery2.visible = true;
        this.dialogLottery2C1.getChildAt(3).loadTexture(pn, 0)
        game.add.tween(this.dialogLottery2Bg).to({
            alpha: 1
        }, 800, Phaser.Easing.Linear.none, true, 0);
        game.add.tween(this.dialogLottery2C1).to({
            y: 0
        }, 800, Phaser.Easing.Back.Out, true, 0)
    },
    startGrab: function () {
        var _this = this;
        _this.isUp = false;
        var t = game.add.tween(this.jiaziGroup).to({
            y: 290
        }, 300, Phaser.Easing.Linear.none, true, 0);
        this.isDown = true;
        this.soundZhuaQu.play()
        t.onComplete.add(function () {
            _this.isUp = true;
            _this.isDown = false;
            var t2;
            if (_this.isCatch) {
                t2 = game.add.tween(this.jiaziGroup).to({
                    y: 0
                }, 3000, Phaser.Easing.Linear.Back, true, 0);
            } else {
                t2 = game.add.tween(this.jiaziGroup).to({
                    y: 0
                }, 300, Phaser.Easing.Linear.Back, true, 0);
            }
            t2.onComplete.add(function () {
                _this.isgrabing = false;
                if (_this.isCatch) {
                    return
                }
                _this.jiaziGroup.children[1].angle = 0;
                _this.jiaziGroup.children[2].angle = 0;
            })
        }, this);
    },
    moveJiazi: function () {
        var mx = this.jiaziGroup.x + 2 * this.direction;
        if (mx >= 202) {
            mx = 202;
            this.direction = this.direction * -1;
            return
        }
        if (mx <= -202) {
            mx = -202;
            this.direction = this.direction * -1;
            return
        }
        this.jiaziGroup.x = mx;
    },
    hitCheck: function () {
        var _this = this;
        this.productsGroup.forEach(function (i) {
            var gl = i.getChildAt(0);
            var p = i.getChildAt(1);
            if (_this.jiaziGroup.y >= 270 && !_this.isUp) {
                if (gl.x > _this.jiaziLeft.getBounds().x && gl.x + gl.width < _this.jiaziRight.getBounds().x + _this.jiaziRight.getBounds().width + 4) {
                    i.moving = false;
                    _this.isCatch = true;
                    _this.rotate(p.name);

                    var playTimes = parseInt($.cookie('playTimes')) || 0;

                    if (playTimes == 0) {
                        var now = new Date();
                        var nextDay = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 24, 0, 0);
                        var expiresDate = new Date();
                        expiresDate.setTime(nextDay.getTime());
                    }
                    playTimes++
                    $.cookie('playTimes', playTimes, {
                        expires: expiresDate,
                        path: '/'
                    });

                    if (playTimes >= 4) {
                        _this.showNoChance();
                    } else {
                        _this.showNotWinning();

                    }
                    return;
                    $.ajax({
                        type: "post",
                        url: "frmdlzx819cj.aspx?rd=" + Math.random(),
                        data: {
                            pid: p.name.substr(1),
                            openid: openid
                        },
                        dataType: "json",
                        error: function (error) {
                            console.log("%c请求异常", "color:#f44373");
                            _this.isSend = false;
                        },
                        success: function (data) {

                            // var Code = parseInt(data.Code),
                            //     Message = data.Message;

                            // if (Code == -3) {
                            //     //未到开始时间
                            //     _this.showNoBegin();
                            // } else if (Code == -4) {
                            //     //活动已结束
                            //     alert('活动已结束')
                            // } else if (Code == -5) {
                            //     //未登录
                            //     needLogin();
                            // } else if (Code == -8) {
                            //     _this.showNoChance()
                            // } else if (Code == -1) {
                            //     if (parseInt(data.lave) <= 0) {
                            //         _this.showNoChance()
                            //     } else {
                            //         _this.showNotWinning();
                            //     }
                            // } else if (Code == -55) {
                            //     //您已经中过奖了
                            //     _this.lottery2('p' + data.pid + '_b');
                            // } else if (Code == 1) {
                            //     //中奖了
                            //     _this.lottery(p.name + '_b')
                            // } else {
                            //     //  
                            // }
                            //  
                        }
                    });
                }
            }
        })
    },
    rotate: function (n) {
        if (n == 'p1') {
            this.jiaziGroup.children[1].angle = 32;
            this.jiaziGroup.children[2].angle = -32;
        }
        if (n == 'p2') {
            this.jiaziGroup.children[1].angle = 18;
            this.jiaziGroup.children[2].angle = -18
        }
        if (n == 'p3') {
            this.jiaziGroup.children[1].angle = -12;
            this.jiaziGroup.children[2].angle = -5;
        }
        if (n == 'p4') {
            this.jiaziGroup.children[1].angle = 19;
            this.jiaziGroup.children[2].angle = -2;
        }
        if (n == 'p5') {
            this.jiaziGroup.children[1].angle = 25;
            this.jiaziGroup.children[2].angle = -26;
        }
        if (n == 'p6') {
            this.jiaziGroup.children[1].angle = 17;
            this.jiaziGroup.children[2].angle = -16;
        }
    },
    playAgain: function () {
        this.isCatch = false;
        this.jiaziGroup.children[1].angle = 0;
        this.jiaziGroup.children[2].angle = 0
        this.productsGroup.forEach(function (i) {
            if (!i.moving) {
                i.destroy();
            }
        })
    },
    update: function () {
        this.noteMove();
        this.moveJiazi();
        this.updateProductsPos();

        this.lotteryAni();
        if (this.isDown) {
            this.hitCheck();
        }
        if (!this.musicPause) {
            this.musicSwitch.angle += 1;
        }
    },
    noteMove: function () {
        var note1 = this.music1;
        var note2 = this.music2;
        var note3 = this.music3;

        if (this.musicPause) {
            note1.alpha = 0;
            note2.alpha = 0;
            note3.alpha = 0;
            return
        }
        note1.x += 1;
        note1.y -= 0.5;
        note1.alpha += 0.05;
        if (note1.alpha > 1) {
            note1.alpha = 1;
        }
        if (note1.x > note1.x1 + 180) {
            note1.x = note1.x1;
            note1.y = note1.y1;
            note1.alpha = 0;
        }
        note2.x += 0.8;
        note2.y -= 0.2;
        note2.alpha += 0.02;
        if (note2.alpha > 1) {
            note2.alpha = 1;
        }
        if (note2.x > note2.x1 + 100) {
            note2.x = note2.x1;
            note2.y = note2.y1;
            note2.alpha = 0;
        }
        note3.x += 0.6;
        note3.y -= 0.35;
        note3.alpha += 0.06;
        if (note3.alpha > 1) {
            note3.alpha = 1;
        }
        if (note3.x > note3.x1 + 100) {
            note3.x = note3.x1;
            note3.y = note3.y1;
            note3.alpha = 0;
        }
    },
    createProducts: function () {
        var rnd = parseInt(Math.random() * 6 + 1),
            g = this.add.group(),
            gl = g.create(game.world.width, 856, 'gl', 0),
            p = g.create(game.world.width, 856, 'p' + rnd, 0);
        g.moving = true;
        p.x = gl.x + parseInt((gl.width - p.width) / 2);
        p.y = gl.y - p.height + 2;
        p.y2 = p.y;
        p.name = 'p' + rnd;
        this.productsGroup.add(g)
    },
    updateProductsPos: function () {
        var _this = this;
        this.productsGroup.forEach(function (i) {
            var gl = i.getChildAt(0);
            var p = i.getChildAt(1);
            gl.x -= 4;
            if (i.moving) {
                p.x = gl.x + parseInt((gl.width - p.width) / 2);
            } else {
                if (!i.diaoluo) {
                    p.y = _this.jiaziLeft.getBounds().y + _this.jiaziLeft.getBounds().height - 60;
                    p.x = parseInt(_this.jiaziGroup.x + game.world.width / 2 - p.width / 2);
                } else {
                    p.y++;
                    if (p.y >= p.y2) {
                        p.y = p.y2;
                        p.x -= 6;
                    }
                }
            }
            if (p.x + p.width + 685 < 0) {
                i.destroy();
            }
        })
    },
    showShare: function () {
        this.shareGroup.alpha = 0;
        this.shareGroup.visible = true;
        game.add.tween(this.shareGroup).to({
            alpha: 1
        }, 600, Phaser.Easing.Linear.none, true, 0)
    }
};
var game = new Phaser.Game(750, 1205, Phaser.CANVAS, 'game', '', true);
game.state.add('Boot', MyGame.Boot);
game.state.add('Preloader', MyGame.Preloader);
game.state.add('Game', MyGame.Game);
game.state.start('Boot');