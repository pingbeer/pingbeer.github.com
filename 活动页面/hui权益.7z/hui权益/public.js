(function () {
	document.addEventListener('DOMContentLoaded', function () {
		var html = document.documentElement;
		var windowWidth = html.clientWidth;
		html.style.fontSize = windowWidth / 6.4 + 'px';
		// html.style.fontSize = windowWidth / 32 + 'px';
	}, false);
})();
// inArray();
if (typeof Array.inArray === 'undefined') {
	Array.prototype.inArray = function(obj) {
		for (var i = 0; i < this.length; i++) {
			if (obj == this[i]) {
				return true;
			}
		}
		return false;
	};
}
// 活动信息
var state_list = {
	'1': '活动未开始',
	'2': '活动进行中',
	'3': '活动已过期',
	'4': '今日待参与',
	'5': '今日已完成',
	'6': '本周已完成',
	'7': '本月已完成',
	'8': '活动已完成'
};
function no_result() {
	layer.msg('没有数据', {
		anim: 1,
		time: 1000
	}, function() {
		window.history.back();
	});
}
/**
 * ajaxPackage                 ajax封装
 * @param  {[type]}   url      [description]
 * @param  {[type]}   datas    [description]
 * @param  {Function} callback [description]
 * @return {[type]}            [description]
 */
var request;// 请求
function ajaxPackage(url, datas, callback) {
	if(request != null)  request.abort();
	var index = '';
	if (typeof layer.load != 'undefined') {
		index = layer.load(2);
	} else {
		index = layer.open({
			type: 2,
			className: 'layer-mobile-loading',
			shade: 'background-color: rgba(255,255,255,0)',
			shadeClose: false
		});
	}
	request = $.ajax({
		url: url,
		type: "POST",
		data: datas,
		dataType: "json",
		success: function(data) {
			layer.close(index);
			if(data.result) {
				callback(data.result);
			}else{
				if (data.status == 'n') {
					if (typeof layer.msg != 'undefined') {
						layer.msg(data.info);
					} else {
						layer.open({
							content: data.info,
							skin: 'msg',
							time: 1
						});
					}
					return false;
				}
				callback(data);
			}
		}
	});
}
/**
 * parseUrl    获取url参数
 * @return object
 */
function parseUrl() {
	var param = location.search;
	var paramObj = {};
	if (param == '') {
		return paramObj;
	}
	param = param.substr(param.indexOf('?')+1);
	if(param.indexOf('&') != -1) {
		param = param.split('&');
		for (var i = 0; i < param.length; i++) {
			var single = param[i].split('=');
			paramObj[single[0]] = decodeURI(single[1]);
		}
	}else{
		param = param.split('=');
		paramObj[param[0]] = decodeURI(param[1]);
	}
	return paramObj;
}
/**
 * 将字符转为utf8
 * @param  string   str 转义的字符
 */
function utf16to8(str) {
	var out, i, len, c;
	out = "";
	len = str.length;
	for (i = 0; i < len; i++) {
		c = str.charCodeAt(i);
		if ((c >= 0x0001) && (c <= 0x007F)) {
			out += str.charAt(i);
		} else if (c > 0x07FF) {
			out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
			out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F));
			out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
		} else {
			out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F));
			out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
		}  
	}  
	return out;
}
/**
 * numberFill      数字转换小数
 * @param  int num  
 * @return
 */
function numberFill(num) {
	var numStr = num.toString();
	var floatLen = numStr.indexOf('.');
	var numLen = numStr.length;
	if (floatLen == -1) {
		return numStr + '.00';
	} else {
		switch (numLen - floatLen) {
			case 2:
				return numStr + '0';
			case 3:
				return numStr;
		}
	}
}
// 计时器
function countDown(intDiff, obj){
	var settime = window.setInterval(function(){
		var hour = 0, minute = 0, second = 0;
		if (intDiff <= 0) {
			clearInterval(settime);
		}
		hour = Math.floor(intDiff / (60 * 60));
		minute = Math.floor(intDiff / 60) - (hour * 60);
		second = Math.floor(intDiff) - (hour * 60 * 60) - (minute * 60);
		if (minute <= 9) minute = '0' + minute;
		if (second <= 9) second = '0' + second;
		obj.html(hour + ':' + minute + ':' + second);
		intDiff--;
	}, 1000);
}
// 关注
function in_attention(obj) {
	obj.data('join', 'out');
	obj.find('img').attr('src', '/views/default/skin/icons/heart-red@2x.png');
	obj.find('span').addClass('red').html('移除管理');
	$('.navbar .update-schedule, .navbar .progress-completion').show();
}
// 取消关注
function cancel_attention(obj) {
	obj.data('join', 'in');
	obj.find('img').attr('src', '/views/default/skin/icons/heart-gray@2x.png');
	obj.find('.red').removeClass('red').html('加入管理');
	$('.navbar .update-schedule, .navbar .progress-completion').hide();
}
// 滑动加载更多
function scrollLoading(callback) {
	var _startY = 0, _moveY = 0;
	$(window).on('touchstart touchmove touchend scroll',function(e) {
		var maxScrollTop = $(document).height() - $(window).height();
		var nowScrollTop = $(window).scrollTop();
		if( e.type != "scroll") {
			var _touch = e.originalEvent.targetTouches[0];
		}
		if (e.type == "touchstart") {
			_startY = _touch.pageY;
		}
		if (e.type == "touchmove") {
			_moveY = _touch.pageY;
		}

		if ( (e.type == "touchend" || e.type == 'scroll') && _startY > 0 && _moveY > 0 ) {
			if ( (_startY - _moveY) > 30 ) {
				if ( (maxScrollTop - $(document).scrollTop()) <= ($('.act_list').height() * 0.5) ) {
					callback();
					_startY = 0;
					_moveY = 0;
				}
			}
			if( (_startY - _moveY) < -30 ) {
				console.log('上移');
			}
		}
	});
}
// 滑动加载更多第二版
function touchLoading(callback){
	var obj, startx, starty, overx, overy, remToPx, nowScrollTop, scrollHeight, windowHeight;
	window.addEventListener('touchstart', function(event) {
		startx = event.touches[0].clientX;
		starty = event.touches[0].clientY;
	} , false);
	window.addEventListener('touchmove', function(event) {
		overx = event.touches[0].clientX;
		overy = event.touches[0].clientY;
	} , false);
	window.addEventListener('touchend', function(event) {
		remToPx			= document.documentElement.clientWidth/ 6.4;
		nowScrollTop	= $(this).scrollTop();
		scrollHeight	= $(document).height();
		windowHeight	= $(this).height();
		console.log(scrollHeight);

		if (starty - overy > 30) {
			if(nowScrollTop + windowHeight >= scrollHeight){
				callback();
				$('body').animate({
					scrollTop: (nowScrollTop - parseInt(remToPx) * 0.64) + 'px'
				}, 300);
			}
		}
		starty = undefined, overy = undefined;
	} , false);
}
$(function() {
	// 快速点击
	FastClick.attach(document.body);
	// 点击穿透
	$('.level-1').on('touch', 'a', function(e) {
		e.stopPropagation();
	})
	// 达标数字减1
	$('body').on('click', '.number .img-minus', function() {
		if ($(this).next().val() == 0) {
			return false;
		}
		$(this).next().val(parseInt($(this).next().val()) - 1);
	});
	$('body').on('click', '.number .img-plus', function() {
		if ($(this).prev().val() == $(this).prev().prop('max')) {
			return false;
		}
		$(this).prev().val(parseInt($(this).prev().val()) + 1);
	});
	// 更新进度手动输入数字判断
	$('body').on('blur', '.rDialog .number input[type=text]', function(e) {
		if($(this).val() > $(this).prop('max')) {
			$(this).val($(this).prop('max'));
			layer.msg('填写的数字不正确, 最大值为:'+$(this).prop('max'));
			return false;
		}

	});
	// 不再提醒
	$('body').on('click', '.remind', function() {
		var remindImg = $(this).find('.checkbox-img');
		if (remindImg.data('switch') == 'yes') {
			remindImg.data('switch', 'no');
			remindImg.attr('src', '/views/default/skin/icons/Checkbox-off@2x.png');
		}else{
			remindImg.data('switch', 'yes');
			remindImg.attr('src', '/views/default/skin/icons/Checkbox-on@2x.png');
		}
	});
	// 底部菜单按钮url替换
	ajaxPackage('/api/goods/get_user_like_goods', '', function(data) {
		ajaxPackage('/api/goods/get_user_like_buy_goods', '', function(data) {
			if (data.status == 'y') {
				if (data.info == 'all') {
					$('.footer_want_to_buy').attr('href', '/web/category/list');
				}
				if (data.info == 'my') {
					$('.footer_want_to_buy').attr('href', '/web/category/collection_list');
				}
			}
		});
		if (data.status == 'y') {
			if (data.info == 'all') {
				$('.footer_want_to_sell').attr('href', '/web/goods/sys_buy_list');
			}
			if (data.info == 'my') {
				$('.footer_want_to_sell').attr('href', '/web/goods/sys_buy_collection_list');
			}
		}
	});
	
});