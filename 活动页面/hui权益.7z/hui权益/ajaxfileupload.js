<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="format-detection" content="telephone=no">
	<title>惠权益</title>
	<link rel="stylesheet" href="/views/default/skin/css/style.css">
</head>
<body>

<div class="menu-bg mb-8" style="height:0.76rem;">
	<div class="menu">
		<div class="level-1 col-5-9 bd-r on"><a href="/web/category/list">全部商品</a></div>
		<div class="level-1 col-5-9 "><a href="/web/category/collection_list">商品收藏</a></div>
	</div>
</div>

<section class="categroy_list">
			<a href="/web/goods/list?cat_id=2">
			<div class="banner pos-r mb-8" style="background-image:url('/public/images/material/banner-美食@2x.png');">
								<div class="title pl-12">美食券</div>
				<div class="logo pl-12 mb-8" style="background-image:url('');"></div>
				<div class="status pl-12">
									<span>出售中：212个</span>
					<span class="ml-24">已成交：9479单</span>
								</div>
			</div>
		</a>
			<a href="/web/goods/list?cat_id=5">
			<div class="banner pos-r mb-8" style="background-image:url('/public/images/material/banner-购物@2x.png');">
								<div class="title pl-12">购物券</div>
				<div class="logo pl-12 mb-8" style="background-image:url('');"></div>
				<div class="status pl-12">
									<span>出售中：68个</span>
					<span class="ml-24">已成交：9677单</span>
								</div>
			</div>
		</a>
			<a href="/web/goods/list?cat_id=8">
			<div class="banner pos-r mb-8" style="background-image:url('/public/images/material/banner-出行@2x.png');">
								<div class="title pl-12">出行券</div>
				<div class="logo pl-12 mb-8" style="background-image:url('');"></div>
				<div class="status pl-12">
									<span>出售中：37个</span>
					<span class="ml-24">已成交：5804单</span>
								</div>
			</div>
		</a>
			<a href="/web/goods/list?cat_id=3">
			<div class="banner pos-r mb-8" style="background-image:url('/public/images/material/banner-opera@2x.png');">
								<div class="title pl-12">票务影视</div>
				<div class="logo pl-12 mb-8" style="background-image:url('');"></div>
				<div class="status pl-12">
									<span>出售中：23个</span>
					<span class="ml-24">已成交：3800单</span>
								</div>
			</div>
		</a>
			<a href="/web/goods/list?cat_id=7">
			<div class="banner pos-r mb-8" style="background-image:url('/public/images/material/banner-流量@2x.png');">
								<div class="title pl-12">流量娱乐</div>
				<div class="logo pl-12 mb-8" style="background-image:url('');"></div>
				<div class="status pl-12">
									<span>出售中：20个</span>
					<span class="ml-24">已成交：5116单</span>
								</div>
			</div>
		</a>
			<a href="/web/goods/list?cat_id=1">
			<div class="banner pos-r mb-8" style="background-image:url('/public/images/material/banner-starbucks@2x.png');">
								<div class="title pl-12">咖啡券</div>
				<div class="logo pl-12 mb-8" style="background-image:url('');"></div>
				<div class="status pl-12">
									<span>出售中：14个</span>
					<span class="ml-24">已成交：8356单</span>
								</div>
			</div>
		</a>
			<a href="/web/goods/list?cat_id=6">
			<div class="banner pos-r mb-8" style="background-image:url('/public/images/material/banner-电影票@2x.png');">
								<div class="title pl-12">电影票</div>
				<div class="logo pl-12 mb-8" style="background-image:url('');"></div>
				<div class="status pl-12">
									<span>出售中：1个</span>
					<span class="ml-24">已成交：6817单</span>
								</div>
			</div>
		</a>
	</section>

<!-- footer -->
<footer>
	<div class="blank"></div>
	<div class="navbar">
		<div class="navwrap flexbox">
			<a href="https://www.bettercard.cn/web/category/list.html" class="navbar_a navbar-border-right footer_want_to_buy">
				<p class="navbar_label">
					<span class="red">我要买</span>
				</p>
			</a>
			<a href="https://www.bettercard.cn/web/goods/sys_buy_list.html" class="navbar_a navbar-border-right footer_want_to_sell">
				<p class="navbar_label">
					<span class="">我要卖</span>
				</p>
			</a>
			<a href="https://www.bettercard.cn/web/my/index.html"  class="navbar_a">
				<p class="navbar_label">
					<span class="">我的</span>
				</p>
			</a>
		</div>
	</div>
</footer>

<script src="/public/js/jquery.js"></script>
<script src="/public/js/layer/layer.js"></script>
<script src="/views/default/skin/js/fastclick.js"></script>
<script src="/views/default/skin/js/public.js"></script>
</body>
</html>