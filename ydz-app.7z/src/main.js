// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import FastClick from 'fastclick'
import VueRouter from 'vue-router'
import App from './App'
// import 'lib-flexible'
import './assets/font-awesome/css/main.css'
import router from './router'
import { AjaxPlugin } from 'vux'
import axios from 'axios'
import echarts from 'echarts'
import store from './store/index.js'
// import VueResource from 'vue-resource'  
// Vue.use(VueResource) 
Vue.use(AjaxPlugin);
//Vue.use(VueRouter)
Vue.prototype.$echarts = echarts;
Vue.prototype.axios = axios;

//const routes = [{
//path: '/',
//component: Home
//}]
var method = [{"contacterId": "1", "contacterName": "现金"}, {
                "contacterId": "2",
                "contacterName": "银行转账"
            }, {"contacterId": "3", "contacterName": "信用卡"}, {
                "contacterId": "4",
                "contacterName": "支付宝"
            }, {"contacterId": "5", "contacterName": "微信钱包"}, {"contacterId": "6", "contacterName": "其他"}];
Vue.filter('number', value => {
  if (value < 10) {
    return parseInt(value)
  } else {
    return value
  }
})
Vue.filter('type', value => {
  if (value == 1) {
    return value = "有限公司"
  } else {
    return value = "个体工商户"
  }
})
Vue.filter('money', value => {
  return parseFloat(value).toFixed(2)
})
Vue.filter('Price', value => {
  if (value == "") {
    return value = '0.00'
  } else {
    return value
  }
})
Vue.filter('image', value => {
  if (value) {
    if (value.indexOf('http') > -1) {
      return value
    } else {
      return "https://www.yiduizhang.com" + value
    }

  }
})
Vue.filter('message', value => {
  if (value.length > 12) {
    return value.substr(0, 12) + ' . . .'
  } else {
    return value
  }

})
Vue.filter('casedesc', value => {
  if (value.length > 23) {
    return value.substr(0, 23) + '...'
  } else if (value == "") {
    return "内容未填"
  } else {
    return value
  }

})
Vue.filter('firm', value => {
  if (value) {
    if (value.length > 11) {
      return value.substr(0, 10) + '...'
    } else {
      return value
    }
  }
})
Vue.filter('character', value => {
  if (value) {
    if (value.length > 5) {
      return value.substr(0, 5) + '...'
    } else {
      return value
    }
  }
})
Vue.filter('kong', value => {
  if (value == "" || value == null) {
    return '—'
  } else {
    return value
  }
})
Vue.filter('content', value => {
  if (value == "" || value == null || value == "  ") {
    return "未填写"
  } else {
    return value
  }
})

Vue.filter('spenderName', value => {
return value.substr(value.length-2)
})
Vue.filter('pattern', value => {
  for(var i=0;i<method.length;i++){
    if(value==method[i].contacterId){
      return method[i].contacterName
    }
  }
})

Vue.filter('summation', value => {
  var nb  = 0;
  for(var i=0;i<value.length;i++){
       if(value[i].money!=""){
        nb += parseInt(value[i].money);
       }
  }
 return parseFloat(nb).toFixed(2)
})
//const router = new VueRouter({
//routes
//})

FastClick.attach(document.body)

Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app-box')







